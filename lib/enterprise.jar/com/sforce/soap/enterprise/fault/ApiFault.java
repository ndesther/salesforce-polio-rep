package com.sforce.soap.enterprise.fault;

/**
 * Generated class, please do not edit.
 */
public class ApiFault extends com.sforce.ws.SoapFaultException implements com.sforce.ws.bind.XMLizable {  private static final long serialVersionUID = 1L;
  /**
   * Constructor
   */
  public ApiFault() {
  }
    
  
  /**
   * element  : exceptionCode of type {urn:fault.enterprise.soap.sforce.com}ExceptionCode
   * java type: com.sforce.soap.enterprise.fault.ExceptionCode
   */
  private static final com.sforce.ws.bind.TypeInfo exceptionCode__typeInfo =
    new com.sforce.ws.bind.TypeInfo("urn:fault.enterprise.soap.sforce.com","exceptionCode","urn:fault.enterprise.soap.sforce.com","ExceptionCode",1,1,true);

  private boolean exceptionCode__is_set = false;

  private com.sforce.soap.enterprise.fault.ExceptionCode exceptionCode;

  public com.sforce.soap.enterprise.fault.ExceptionCode getExceptionCode() {
    return exceptionCode;
  }

  

  public void setExceptionCode(com.sforce.soap.enterprise.fault.ExceptionCode exceptionCode) {
    this.exceptionCode = exceptionCode;
    exceptionCode__is_set = true;
  }
  
  /**
   * element  : exceptionMessage of type {http://www.w3.org/2001/XMLSchema}string
   * java type: java.lang.String
   */
  private static final com.sforce.ws.bind.TypeInfo exceptionMessage__typeInfo =
    new com.sforce.ws.bind.TypeInfo("urn:fault.enterprise.soap.sforce.com","exceptionMessage","http://www.w3.org/2001/XMLSchema","string",1,1,true);

  private boolean exceptionMessage__is_set = false;

  private java.lang.String exceptionMessage;

  public java.lang.String getExceptionMessage() {
    return exceptionMessage;
  }

  

  public void setExceptionMessage(java.lang.String exceptionMessage) {
    this.exceptionMessage = exceptionMessage;
    exceptionMessage__is_set = true;
  }
  
  /**
   * element  : extendedErrorDetails of type {urn:enterprise.soap.sforce.com}ExtendedErrorDetails
   * java type: com.sforce.soap.enterprise.ExtendedErrorDetails[]
   */
  private static final com.sforce.ws.bind.TypeInfo extendedErrorDetails__typeInfo =
    new com.sforce.ws.bind.TypeInfo("urn:fault.enterprise.soap.sforce.com","extendedErrorDetails","urn:enterprise.soap.sforce.com","ExtendedErrorDetails",0,-1,true);

  private boolean extendedErrorDetails__is_set = false;

  private com.sforce.soap.enterprise.ExtendedErrorDetails[] extendedErrorDetails = new com.sforce.soap.enterprise.ExtendedErrorDetails[0];

  public com.sforce.soap.enterprise.ExtendedErrorDetails[] getExtendedErrorDetails() {
    return extendedErrorDetails;
  }

  

  public void setExtendedErrorDetails(com.sforce.soap.enterprise.ExtendedErrorDetails[] extendedErrorDetails) {
    this.extendedErrorDetails = extendedErrorDetails;
    extendedErrorDetails__is_set = true;
  }
  

  /**
   */
  public void write(javax.xml.namespace.QName __element,
      com.sforce.ws.parser.XmlOutputStream __out, com.sforce.ws.bind.TypeMapper __typeMapper)
      throws java.io.IOException {
    __out.writeStartTag(__element.getNamespaceURI(), __element.getLocalPart());
    
    writeFields(__out, __typeMapper);
    __out.writeEndTag(__element.getNamespaceURI(), __element.getLocalPart());
  }

  protected void writeFields(com.sforce.ws.parser.XmlOutputStream __out,
      com.sforce.ws.bind.TypeMapper __typeMapper) throws java.io.IOException {
   
    __typeMapper.writeObject(__out, exceptionCode__typeInfo, exceptionCode, exceptionCode__is_set);
    __typeMapper.writeString(__out, exceptionMessage__typeInfo, exceptionMessage, exceptionMessage__is_set);
    __typeMapper.writeObject(__out, extendedErrorDetails__typeInfo, extendedErrorDetails, extendedErrorDetails__is_set);
  }


  public void load(com.sforce.ws.parser.XmlInputStream __in,
      com.sforce.ws.bind.TypeMapper __typeMapper) throws java.io.IOException, com.sforce.ws.ConnectionException {
    __typeMapper.consumeStartTag(__in);
    loadFields(__in, __typeMapper);
    __typeMapper.consumeEndTag(__in);
  }

  protected void loadFields(com.sforce.ws.parser.XmlInputStream __in,
      com.sforce.ws.bind.TypeMapper __typeMapper) throws java.io.IOException, com.sforce.ws.ConnectionException {
   
    __in.peekTag();
    if (__typeMapper.verifyElement(__in, exceptionCode__typeInfo)) {
      setExceptionCode((com.sforce.soap.enterprise.fault.ExceptionCode)__typeMapper.readObject(__in, exceptionCode__typeInfo, com.sforce.soap.enterprise.fault.ExceptionCode.class));
    }
    __in.peekTag();
    if (__typeMapper.verifyElement(__in, exceptionMessage__typeInfo)) {
      setExceptionMessage((java.lang.String)__typeMapper.readString(__in, exceptionMessage__typeInfo, java.lang.String.class));
    }
    __in.peekTag();
    if (__typeMapper.isElement(__in, extendedErrorDetails__typeInfo)) {
      setExtendedErrorDetails((com.sforce.soap.enterprise.ExtendedErrorDetails[])__typeMapper.readObject(__in, extendedErrorDetails__typeInfo, com.sforce.soap.enterprise.ExtendedErrorDetails[].class));
    }
  }

  public String toString() {
    java.lang.StringBuilder sb = new java.lang.StringBuilder();
    sb.append("[ApiFault ");
    
    sb.append(" exceptionCode=");
    sb.append("'"+com.sforce.ws.util.Verbose.toString(exceptionCode)+"'\n");
    sb.append(" exceptionMessage=");
    sb.append("'"+com.sforce.ws.util.Verbose.toString(exceptionMessage)+"'\n");
    sb.append(" extendedErrorDetails=");
    sb.append("'"+com.sforce.ws.util.Verbose.toString(extendedErrorDetails)+"'\n");
    sb.append("]\n");
    return sb.toString();
  }
}