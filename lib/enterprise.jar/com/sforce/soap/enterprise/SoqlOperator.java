package com.sforce.soap.enterprise;

/**
 * Generated enum, please do not edit.
 */
public enum SoqlOperator {

  
  /**
   * Enumeration  : equals
   */
   equals,
  
  /**
   * Enumeration  : excludes
   */
   excludes,
  
  /**
   * Enumeration  : greaterThan
   */
   greaterThan,
  
  /**
   * Enumeration  : greaterThanOrEqualTo
   */
   greaterThanOrEqualTo,
  
  /**
   * Enumeration  : in
   */
   in,
  
  /**
   * Enumeration  : includes
   */
   includes,
  
  /**
   * Enumeration  : lessThan
   */
   lessThan,
  
  /**
   * Enumeration  : lessThanOrEqualTo
   */
   lessThanOrEqualTo,
  
  /**
   * Enumeration  : like
   */
   like,
  
  /**
   * Enumeration  : notEquals
   */
   notEquals,
  
  /**
   * Enumeration  : notIn
   */
   notIn,
  
  /**
   * Enumeration  : within
   */
   within,
  
}