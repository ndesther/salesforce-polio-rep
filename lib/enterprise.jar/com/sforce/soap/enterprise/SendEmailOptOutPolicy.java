package com.sforce.soap.enterprise;

/**
 * Generated enum, please do not edit.
 */
public enum SendEmailOptOutPolicy {

  
  /**
   * Enumeration  : SEND
   */
   SEND,
  
  /**
   * Enumeration  : FILTER
   */
   FILTER,
  
  /**
   * Enumeration  : REJECT
   */
   REJECT,
  
}