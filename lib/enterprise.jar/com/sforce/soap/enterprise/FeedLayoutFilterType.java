package com.sforce.soap.enterprise;

/**
 * Generated enum, please do not edit.
 */
public enum FeedLayoutFilterType {

  
  /**
   * Enumeration  : AllUpdates
   */
   AllUpdates,
  
  /**
   * Enumeration  : FeedItemType
   */
   FeedItemType,
  
  /**
   * Enumeration  : Custom
   */
   Custom,
  
}