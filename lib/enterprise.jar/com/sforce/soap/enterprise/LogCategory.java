package com.sforce.soap.enterprise;

/**
 * Generated enum, please do not edit.
 */
public enum LogCategory {

  
  /**
   * Enumeration  : Db
   */
   Db,
  
  /**
   * Enumeration  : Workflow
   */
   Workflow,
  
  /**
   * Enumeration  : Validation
   */
   Validation,
  
  /**
   * Enumeration  : Callout
   */
   Callout,
  
  /**
   * Enumeration  : Apex_code
   */
   Apex_code,
  
  /**
   * Enumeration  : Apex_profiling
   */
   Apex_profiling,
  
  /**
   * Enumeration  : Visualforce
   */
   Visualforce,
  
  /**
   * Enumeration  : System
   */
   System,
  
  /**
   * Enumeration  : All
   */
   All,
  
}