package com.sforce.soap.enterprise;

/**
 * Generated enum, please do not edit.
 */
public enum EmailPriority {

  
  /**
   * Enumeration  : Highest
   */
   Highest,
  
  /**
   * Enumeration  : High
   */
   High,
  
  /**
   * Enumeration  : Normal
   */
   Normal,
  
  /**
   * Enumeration  : Low
   */
   Low,
  
  /**
   * Enumeration  : Lowest
   */
   Lowest,
  
}