package com.sforce.soap.enterprise;

/**
 * Generated enum, please do not edit.
 */
public enum LogCategoryLevel {

  
  /**
   * Enumeration  : None
   */
   None,
  
  /**
   * Enumeration  : Finest
   */
   Finest,
  
  /**
   * Enumeration  : Finer
   */
   Finer,
  
  /**
   * Enumeration  : Fine
   */
   Fine,
  
  /**
   * Enumeration  : Debug
   */
   Debug,
  
  /**
   * Enumeration  : Info
   */
   Info,
  
  /**
   * Enumeration  : Warn
   */
   Warn,
  
  /**
   * Enumeration  : Error
   */
   Error,
  
}