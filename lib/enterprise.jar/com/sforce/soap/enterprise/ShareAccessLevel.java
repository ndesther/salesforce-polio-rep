package com.sforce.soap.enterprise;

/**
 * Generated enum, please do not edit.
 */
public enum ShareAccessLevel {

  
  /**
   * Enumeration  : Read
   */
   Read,
  
  /**
   * Enumeration  : Edit
   */
   Edit,
  
  /**
   * Enumeration  : All
   */
   All,
  
}