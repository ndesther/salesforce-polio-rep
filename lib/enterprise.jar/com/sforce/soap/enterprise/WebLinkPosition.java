package com.sforce.soap.enterprise;

/**
 * Generated enum, please do not edit.
 */
public enum WebLinkPosition {

  
  /**
   * Enumeration  : fullScreen
   */
   fullScreen,
  
  /**
   * Enumeration  : none
   */
   none,
  
  /**
   * Enumeration  : topLeft
   */
   topLeft,
  
}