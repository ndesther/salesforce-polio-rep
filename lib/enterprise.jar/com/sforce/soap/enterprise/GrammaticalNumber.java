package com.sforce.soap.enterprise;

/**
 * Generated enum, please do not edit.
 */
public enum GrammaticalNumber {

  
  /**
   * Enumeration  : Singular
   */
   Singular,
  
  /**
   * Enumeration  : Plural
   */
   Plural,
  
}