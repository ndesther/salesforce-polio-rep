package com.sforce.soap.enterprise;

/**
 * Generated enum, please do not edit.
 */
public enum WebLinkType {

  
  /**
   * Enumeration  : url
   */
   url,
  
  /**
   * Enumeration  : sControl
   */
   sControl,
  
  /**
   * Enumeration  : javascript
   */
   javascript,
  
  /**
   * Enumeration  : page
   */
   page,
  
  /**
   * Enumeration  : flow
   */
   flow,
  
}