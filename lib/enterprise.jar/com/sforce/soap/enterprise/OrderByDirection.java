package com.sforce.soap.enterprise;

/**
 * Generated enum, please do not edit.
 */
public enum OrderByDirection {

  
  /**
   * Enumeration  : ascending
   */
   ascending,
  
  /**
   * Enumeration  : descending
   */
   descending,
  
}