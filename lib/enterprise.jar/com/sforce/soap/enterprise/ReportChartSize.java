package com.sforce.soap.enterprise;

/**
 * Generated enum, please do not edit.
 */
public enum ReportChartSize {

  
  /**
   * Enumeration  : SMALL
   */
   SMALL,
  
  /**
   * Enumeration  : MEDIUM
   */
   MEDIUM,
  
  /**
   * Enumeration  : LARGE
   */
   LARGE,
  
}