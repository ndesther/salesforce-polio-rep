package com.sforce.soap.enterprise;

/**
 * Generated enum, please do not edit.
 */
public enum FlexipageContextTypeEnum {

  
  /**
   * Enumeration  : ENTITYNAME
   */
   ENTITYNAME,
  
}