package com.sforce.soap.enterprise;

/**
 * Generated enum, please do not edit.
 */
public enum DifferenceType {

  
  /**
   * Enumeration  : DIFFERENT
   */
   DIFFERENT,
  
  /**
   * Enumeration  : NULL
   */
   NULL,
  
  /**
   * Enumeration  : SAME
   */
   SAME,
  
  /**
   * Enumeration  : SIMILAR
   */
   SIMILAR,
  
}