package com.sforce.soap.enterprise;

/**
 * Generated enum, please do not edit.
 */
public enum DebugLevel {

  
  /**
   * Enumeration  : None
   */
   None,
  
  /**
   * Enumeration  : DebugOnly
   */
   DebugOnly,
  
  /**
   * Enumeration  : Db
   */
   Db,
  
  /**
   * Enumeration  : Profiling
   */
   Profiling,
  
  /**
   * Enumeration  : Callout
   */
   Callout,
  
  /**
   * Enumeration  : Detail
   */
   Detail,
  
}