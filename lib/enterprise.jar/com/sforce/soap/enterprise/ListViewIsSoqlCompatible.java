package com.sforce.soap.enterprise;

/**
 * Generated enum, please do not edit.
 */
public enum ListViewIsSoqlCompatible {

  
  /**
   * Enumeration  : TRUE
   */
   TRUE,
  
  /**
   * Enumeration  : FALSE
   */
   FALSE,
  
  /**
   * Enumeration  : ALL
   */
   ALL,
  
}