package com.sforce.soap.enterprise;

/**
 * Generated enum, please do not edit.
 */
public enum WebLinkWindowType {

  
  /**
   * Enumeration  : newWindow
   */
   newWindow,
  
  /**
   * Enumeration  : sidebar
   */
   sidebar,
  
  /**
   * Enumeration  : noSidebar
   */
   noSidebar,
  
  /**
   * Enumeration  : replace
   */
   replace,
  
  /**
   * Enumeration  : onClickJavaScript
   */
   onClickJavaScript,
  
}