package com.sforce.soap.enterprise;

/**
 * Generated enum, please do not edit.
 */
public enum TabOrderType {

  
  /**
   * Enumeration  : LeftToRight
   */
   LeftToRight,
  
  /**
   * Enumeration  : TopToBottom
   */
   TopToBottom,
  
}