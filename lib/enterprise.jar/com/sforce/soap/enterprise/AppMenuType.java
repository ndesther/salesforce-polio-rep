package com.sforce.soap.enterprise;

/**
 * Generated enum, please do not edit.
 */
public enum AppMenuType {

  
  /**
   * Enumeration  : AppSwitcher
   */
   AppSwitcher,
  
  /**
   * Enumeration  : Salesforce1
   */
   Salesforce1,
  
  /**
   * Enumeration  : NetworkTabs
   */
   NetworkTabs,
  
}