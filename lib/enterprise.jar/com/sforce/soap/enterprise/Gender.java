package com.sforce.soap.enterprise;

/**
 * Generated enum, please do not edit.
 */
public enum Gender {

  
  /**
   * Enumeration  : Neuter
   */
   Neuter,
  
  /**
   * Enumeration  : Masculine
   */
   Masculine,
  
  /**
   * Enumeration  : Feminine
   */
   Feminine,
  
  /**
   * Enumeration  : AnimateMasculine
   */
   AnimateMasculine,
  
}